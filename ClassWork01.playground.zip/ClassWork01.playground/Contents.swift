import UIKit
import Darwin
import Foundation

//Task 1


protocol Shape {
    func space() -> Double
}

struct Circle: Shape {
    let pi = 3.14
    var radius: Double
    
    func space() -> Double {
        return pi * radius * radius
    }
}

struct Square: Shape{
    let side: Double
    
    func space() -> Double {
        return side * side
    }
    
}

struct Triangle: Shape {
    let height: Double
    let side: Double
    
    func space() -> Double {
        return (side * height) / 2
    }
}


var circle = Circle(radius: 5)
circle.space()

var square = Square(side: 10)
square.space()

var triangle = Triangle(height: 10, side: 20)
triangle.space()


//Task2

enum Mark: Int {
    case one = 1
    case two = 2
    case three = 3
    case four = 4
    case five = 5
}

enum Group: String {
    case first = "Best"
    case second = "Medium"
    case third = "Bad"
}

protocol Speach {
    func say()
}

class Student {
    var name: String = ""
    var group = Group.first
    var mark = Mark.five
}

class Professor: Speach {
    var name: String = ""
    var subject: String = ""
    var IsWorking: Bool = true
    var countOfGroups: Int = 0
    func say() {
        print("YOU FAIL !!!")
    }
}

class University {
    var countOfProfessors: Int = 0
    var coureerGroup = Group.first
    var rektorName = ""
}

let student1 = Student()
student1.name = "Radmir"
student1.group.rawValue.first
print(student1.name)

let professor1 = Professor()
professor1.say()



